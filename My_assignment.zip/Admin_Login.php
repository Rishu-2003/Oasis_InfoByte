
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Login</title>

	<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">

	<style type="text/css">
		*{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			font-family: 'Poppins', sans-serif;
		}
		body{
			background: #77ff77;
			backdrop-filter: blur(3px);
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100vh;
		}
		.Admin {
			background: rgba(1, 0, 0, .2);
			position: relative;
			box-shadow: -5px 5px 1rem rgba(0, 0, 0, .5);
			display: flex;
			align-items: center;
/*			justify-content: center;*/
			flex-direction: column;
			width: 22rem;
			height: 25rem;
			padding: 0 1rem;
			gap: 1rem;
			padding: 1.5rem 0;
			border-radius: .3rem;
			overflow: hidden;

		}
		.Admin .header{
			position: relative;
			margin: .6rem 1rem;
			background: #fff;
			display: flex;
/*			align-items: center;*/
			justify-content: center;
			border-radius: 5rem;
		}
		.Admin .header #switch{
			z-index: 9;
			width: 8rem;
			outline: none;
			border: none;
			display: flex;
			align-items: center;
			justify-content: center;
			letter-spacing: .09px;
			background: transparent;
			padding: .6rem 0;
			text-align: center;
			font-size: .8rem;
			border-radius: 5rem;

		}.Admin .header #btn{
			position: absolute;
			width: 8rem;
			height: 100%;
			border-radius: 5rem;
			background: #77ff77;
			left: 0;
			transition: .5s ease;
		}
		.Admin .form-container{
			position: relative;
			height: auto;
			display: flex;
			flex-direction: column;
			align-items: center;
			gap: 1rem;
		}
		.form-list{
			position: absolute;
			display: flex;
			flex-direction: column;
			width: 18rem;
			height: auto;
			background: transparent;
			gap: .8rem;
			padding: .2rem .4rem;
			transition: .5s ease;
		}
		.Login-form{
			left: -9rem;
		}
		.Create-form{
			left: 20rem;
		}
		.form-list span{
			width: 100%;
			height: 2.5rem;
			display: flex;
			align-items: center;
			gap: .5rem;
			color: #444;
			background: transparent;
			padding: 0 1rem;
			border-radius: .2rem;
			border: 2px solid #222;
		}
		.form-list span ion-icon{
			font-size: 1rem;
		}
		.form-list span input{
			border: none;
			color: #fff;
			outline: none;
			width: 100%;
			background: transparent;
		}
		.form-list p{
			color: #555555;
			font-size: .8rem;
			text-align: right;
			cursor: pointer;
		}
		.form-list button{
			text-align: center;
			outline: none;
			background: #fff;
			border-radius: .4rem;
			padding: .5rem .5rem;
			font-size: .9rem;
			border: none;
			color: #00ff00;
			letter-spacing: 1px;
			cursor: pointer;
			width: 	100%;
			font-weight: bold;
		}
		.form-list button a{
			color: #00ff00;
			text-decoration: none;
		}
		.form-list .soical{
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 1.4rem;
			
		}
		.form-list .soical a{
			display: flex;
			align-items: center;
			justify-content: center;
			color: #222;
			font-size: 1.3rem;
			margin-top: .5rem;
			padding: .5rem;
			border-radius: 50%;
			border: 1px solid #333333;
		}
		.form-list .soical a:hover,.form-list .soical a:focus{
			color: #fff;
			border-color: #fff;
		}.admin_login{
			position: relative;
			display: flex;
			width: 100%;
			height: auto;
			top: 15.5rem;
			margin-left: 6rem;
		}
		.admin_login a{
			text-decoration: none;
			margin-left: 1rem;

		}
		.admin_login a input{
			width: 8rem;
			height: 2rem;
			background: #fff;
			color: #000;
			outline: none;
			border: none;
			border-radius: 2rem;
		}
	</style>
</head>
<body>
		<div class="Admin">
			<div class="header">
				<div id="btn"></div>
				<button class="login" id="switch" onclick="login()">Admin Login</button>
				<button class="create" id="switch" onclick="register()">Registration</button>
			</div>
			<div class="form-container">
				<form class="Login-form form-list" id="log" method="POST">
					<span><ion-icon name="mail-open"></ion-icon><input type="email" name="email" placeholder="Email" required></span>
					<span><ion-icon name="lock"></ion-icon><input type="password" name="password" placeholder="Password" required></span>
					<p>Forget password</p>
					<button name="login"><a href="Admin_Dashboard.php">Login</button>
					<div class="soical">
						<a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
						<a href="#"><ion-icon name="logo-googleplus"></ion-icon></a>
						<a href="#"><ion-icon name="logo-github"></ion-icon></a>
					</div>
				</form>
				<form class="Create-form form-list" id="reg" method="POST">
					<span><ion-icon name="person"></ion-icon><input type="text" name="name" placeholder="Name" required></span>
					<span><ion-icon name="mail-open"></ion-icon><input type="email" name="email" placeholder="Email" required></span>
					<span><ion-icon name="lock"></ion-icon><input type="password" name="password" placeholder="Password" required></span>
					<button name="register">Register</button>
					<div class="soical">
						<a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
						<a href="#"><ion-icon name="logo-googleplus"></ion-icon></a>
						<a href="#"><ion-icon name="logo-github"></ion-icon></a>
					</div>
				</form>
			</div>
			<div class="admin_login">Customer Login <a href="index.php"><input type="submit" value="Click here"></a></div>

		</div>

		<script type="text/javascript">
			const	btn=document.getElementById("btn");
			const	x=document.getElementById("log");
			const	y=document.getElementById("reg");
			function register(){
				btn.style.left="8rem";
				y.style.left="-9rem";
				x.style.left="-30rem"
			}
			function login(){
				btn.style.left="0";
				y.style.left="20rem";
				x.style.left="-9rem"
			}
		</script>
</body>
</html>
<?php

if(isset($_POST['login']))
{
	$email=$_POST['email'];
	$password=$_POST['password'];
	$con=mysqli_connect('localhost','root','','intern');
	$select=" select * from admin1 where Email='$email' && Password='$password' ";

	$rs=mysqli_query($con,$select);
	$num=mysqli_num_rows($rs);
	if($num==1){
		// $_SESSION['$rs[name]'];
		// 
		echo $num;
		//echo " <script> alert(User not found);</script>";
	}
	else{
		// 
	}
}

?>