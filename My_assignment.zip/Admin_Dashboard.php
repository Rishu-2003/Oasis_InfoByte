<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home Page</title>
	<style type="text/css">
		*{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
		}
		body{
			height: 100%;
			width: 100%;
			background: #fff;
			position: relative;
			display: flex;
			align-items: center;
			justify-content: center;
			margin-top: 10rem;
			
		}
		body *{
			font-family: Arial;
			border: 2px solid black;
		}
		table{
			width: 50rem;
			height: 10rem;
		}
		th{
			background: #00ff66;
		}
		caption{
			height: 2rem;
			background: #00ff00;
			color: #fff;
			font-weight: bold;
			font-size: 1.5rem;
		}

		td{
			font-size: 1rem;
			text-align: center;
		}
	</style>
</head>
<body>
	<?php
		$con=mysqli_connect("localhost","root","","intern");
		$select="select * from order_page where Company='customer 1'";
		$query=mysqli_query($con,$select);
		$result=mysqli_fetch_assoc($query);
		$quantity=$result['Quantity'];
		$weight=$result['Weight'];
		$box_count=$result['Box_Count'];


		$select1="select * from order_page where Company='company 2'";
		$query1=mysqli_query($con,$select1);
		$result1=mysqli_fetch_assoc($query1);
		$quantity1=$result1['Quantity'];
		$weight1=$result1['Weight'];
		$box_count1=$result1['Box_Count'];


	?>
	<table>
		<caption>Dashboard</caption>
		<tr>
			<th class="r1">Item/Customer</th>
			<th class="r1">Customer1</th>
			<th class="r1">Customer2</th>
			<th class="r1">Total</th>
		</tr>
		<tr>
			<th class="r1">Quantity</th>
			<td><?php echo $quantity; ?></td>
			<td><?php echo $quantity1; ?></td>
			<td><?php echo $quantity + $quantity1; ?></td>
		</tr>
		<tr>
			<th class="r1">Weight</th>
			<td><?php echo $weight; ?></td>
			<td><?php echo $weight1; ?></td>
			<td><?php echo $weight + $weight1; ?></td>
		</tr>
		<tr>
			<th class="r1">Box Count</th>
			<td><?php echo $box_count; ?></td>
			<td><?php echo $box_count1; ?></td>
			<td><?php echo $box_count + $box_count1; ?></td>
		</tr>
	</table>
</body>
</html>