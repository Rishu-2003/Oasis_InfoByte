
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Customers Details</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Rubik:wght@500&display=swap" rel="stylesheet">
	<style type="text/css">
		:root{
			--white:#fff;
			--black:#222222;
			--green:#00ff55;
			--light-bg:#4b4b4b;
			--light-white:#aaa;
		}
		::-webkit-scrollbar{
			width: 0;
			scroll-behavior: smooth;	
		}
		*{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			font-family: 'Rubik', sans-serif;
			transition: .4s ease;

		}
		body{
			
			background: var(--black);
			height: 100vh;
		}
		.container{
			position: relative;
			display: flex;
			align-items: center;
			justify-content: center;
		}
		.wrapper{
			position: relative;
			display: flex;
			align-items: center;
			justify-content: center;
			width: 50%;
			height: 100vh;

		}
		.content{
			background: var(--white);
			padding: 1.5rem 2.5rem;
			border-radius: .5rem;
		}
		.content .title{
			color: var(--green);
			font-size: 2rem;
			text-transform: uppercase;
			text-align: center;
			
		}
		form .input-field {
			position: relative;
			display: flex;
			justify-content: space-between;
			margin: 10px 5px;
			width: auto;
			height: auto;

		}
		form .input-field label{
			display: flex;
			justify-content: space-between;
			align-items: center;
			font-size: .8rem;
			width: 10rem;
			height: auto;
		}
		input[type="text"],input[type="number"],input[type="date"]{
			height: 2rem;
			width: 20rem;
			border: 1px solid var(--light-bg);
			border-radius: .2rem;
			outline: none;
		}
		.btn{
			width: 100%;
			height: auto;
			background: var(--green);
			border-radius: .3rem;
			border: none;
			color: var(--white);
			font-size: 1.2rem;
			letter-spacing: 2px;
			outline: none;
			padding: .5rem;
			text-transform: uppercase;
			transition: .2s ease;

		}.btn:hover{
			background: #00ff44;
		}
		.image{
			position: relative;
			width: 50%;
			height: 100vh;
		}
		.image img{
			height: 100%;
			width: 100%;
		}
		@media screen and (max-width: 1200px){
			.wrapper{
				width: 55%;
			}
			.content{
				padding: 1rem 1.5rem;
			}
			form .input-field {

				margin: 10px 5px;

			}
			form .input-field label{
				width: 9rem;
			}
			input[type="text"],input[type="number"],input[type="date"]{
				height: 2rem;
				width: 18rem;
			}

			.image{
				width: 45%;
			}
			
		}
		@media screen and (max-width: 991px){
			.container{
				position: relative;
				display: flex;
				flex-direction: column;
			}
			.wrapper{
				width: 100%;
			}
			.content{
				padding: 1.5rem 2.5rem;
			}
			form .input-field {

				margin: 10px 5px;

			}
			form .input-field label{
				width: 10rem;
			}
			input[type="text"],input[type="number"],input[type="date"]{
				height: 2rem;
				width: 20rem;
			}

			.image{
				width: 80%;
				height: 30rem;
			}
			
		}
		@media screen and (max-width: 630px){
			.wrapper{
				width: 100%;
			}
			.content{
				padding: .7rem 1.2rem;
			}
			form .input-field {
				margin: 10px 5px;

			}
			form .input-field label{
				width: 9rem;
			}
			input[type="text"],input[type="number"],input[type="date"]{
				height: 2rem;
				width: 16rem;
			}

			.image{
				width: 100%;
			}
			
		}
		@media screen and (max-width: 480px){
			.wrapper{
				width: 100%;
				height: 50rem;
			}
			.content{
				padding: .7rem 1.2rem;
			}
			form .input-field {
				display: flex;
				flex-direction: column;
				margin: 10px 5px;

			}
			form .input-field label{
				width: 9rem;
			}
			input[type="text"],input[type="number"],input[type="date"]{
				height: 2rem;
				width: 16rem;
			}

			.image{
				position: relative;
				height: 23rem;
				
			}
			
		}
			
	</style>
</head>
<body>

	<div class="container">
	<div class="wrapper">
		<div class="content">
			<div class="title">Order Details</div>
			<form method="POST">
				<div class="input-field">
					<label>Company Name</label>
					<input type="text" name="cname" required >
				</div>
				<div class="input-field">
					<label>Owner </label>
					<input type="text" name="owner" required>
				</div>
				<div class="input-field">
					<label>Order Date</label>
					<input type="date" name="date" required>
				</div>
				<div class="input-field">
					<label>Item</label>
					<input type="text" name="item" required>
				</div>
				<div class="input-field">
					<label>Quantity</label>
					<input type="number" name="quantity" required>
				</div>
				<div class="input-field">
					<label>Weight</label>
					<input type="number" name="weight" required>
				</div>
				<div class="input-field">
					<label>Request for shipment</label>
					<input type="text" name="ship" required>
				</div>
				<div class="input-field">
					<label>Tracking Id</label>
					<input type="text" name="track" required>
				</div>
				<div class="input-field">
					<label>Shipment Size</label>
					<input type="text" name="shipSize" required >
				</div>
				<div class="input-field">
					<label>Box Count</label>
					<input type="number" name="boxCount" required>
				</div>
				<div class="input-field">
					<label>Specification</label>
					<input type="text" name="specification">
				</div>
				<div class="input-field">
					<label>Checklist Quanlity</label>
					<input type="text" name="checkQuantity">	
				</div>
				<button class="btn" name="submit">Submit</button>
			</form>
		</div>
	</div>
	<div class="image">
		<img src="order_details.png">
	</div>
</div>
</body>
</html>
<?php
	if(isset($_POST['submit'])){
		$servername="localhost";
		$username="root";
		$password="";
		$dbname="intern";
		$con=mysqli_connect($servername,$username,$password,$dbname);

		$cname=$_POST['cname'];
		$owner=$_POST['owner'];
		$date=$_POST['date'];
		$item=$_POST['item'];
		$quantity=$_POST['quantity'];
		$weight=$_POST['weight'];
		$ship=$_POST['ship'];
		$track=$_POST['track'];
		$shipSize=$_POST['shipSize'];
		$boxCount=$_POST['boxCount'];
		$specification=$_POST['specification'];
		$checkQuantity=$_POST['checkQuantity'];

		$query="INSERT INTO `order_page`(`Company`, `Owner`, `Date`, `Item`, `Quantity`, `Weight`, `Request_For_Shipment`, `Tracking_ID`, `Shipment_Size`, `Box_Count`, `Specification`, `Check_Quantity`) VALUES ('$cname','$owner','$date','$item','$quantity','$weight','$ship','$track','$shipSize','$boxCount','$specification','$checkQuantity')";
		$sql=mysqli_query($con,$query);
		if($sql){
			?>
			<script type="text/javascript">
				window.alert("Order comfirmed...");
			</script>
		<?php
		}else{
			?>
			<script type="text/javascript">
				window.alert("Order comfirmed...");
			</script>
		<?php
		}
	}

?>